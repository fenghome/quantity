import React from 'react';

export default ()=>(
  <div>Test2</div>
)
